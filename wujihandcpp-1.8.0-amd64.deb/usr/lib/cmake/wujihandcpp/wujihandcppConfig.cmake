
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was wujihandcppConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# Transitive dependencies of the installed wujihandcpp library.
include(CMakeFindDependencyMacro)
find_dependency(Threads)

# Static archives need spdlog symbols at consumer link time even though spdlog
# is implementation-detail. Shared installs keep spdlog private and do not
# require consumers to discover it.
if(OFF)
    get_filename_component(_WUJIHANDCPP_CONFIG_DIR "${CMAKE_CURRENT_LIST_FILE}" PATH)
    if(EXISTS "${_WUJIHANDCPP_CONFIG_DIR}/_deps/spdlog-build/spdlogConfig.cmake")
        # Build-tree consumption: spdlog lives where FetchContent put it.
        list(PREPEND CMAKE_PREFIX_PATH "${_WUJIHANDCPP_CONFIG_DIR}/_deps/spdlog-build")
    endif()
    unset(_WUJIHANDCPP_CONFIG_DIR)
    find_dependency(spdlog)
endif()

# usb-1.0 is linked as a bare library name (target_link_libraries(... PUBLIC
# usb-1.0)) and propagated through the imported target as `-lusb-1.0`. No
# find_dependency needed because there is no upstream usb-1.0 CMake target —
# the system loader resolves it at link time.

include("${CMAKE_CURRENT_LIST_DIR}/wujihandcppTargets.cmake")

check_required_components(wujihandcpp)
