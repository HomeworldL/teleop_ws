#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "wujihandcpp::wujihandcpp" for configuration "Release"
set_property(TARGET wujihandcpp::wujihandcpp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wujihandcpp::wujihandcpp PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libwujihandcpp.so"
  IMPORTED_SONAME_RELEASE "libwujihandcpp.so"
  )

list(APPEND _cmake_import_check_targets wujihandcpp::wujihandcpp )
list(APPEND _cmake_import_check_files_for_wujihandcpp::wujihandcpp "${_IMPORT_PREFIX}/lib/libwujihandcpp.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
